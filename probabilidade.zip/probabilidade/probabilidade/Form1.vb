﻿Public Class Form1
    Dim calculo As Double = 0.0
    Dim resultados As New Double
    Dim list As New List(Of Double)
    Dim media As Integer = 40

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        TextBox2.Text = media
    End Sub

    Private Sub TextBox1_KeyDown(sender As Object, e As KeyEventArgs) Handles TextBox1.KeyDown
        If e.KeyCode = Keys.Enter Then
            resultados = Double.Parse(TextBox1.Text)
            list.Add(resultados)
            check()
            PictureBox1.BackColor = base()
            TextBox1.Text = ""
            PictureBox1.ResetText()
        End If
    End Sub
    Public Sub check()
        If resultados > 50 And PictureBox1.BackColor = Color.Green Or resultados < 50 And PictureBox1.BackColor = Color.Red Then
            ListBox1.Items.Add(resultados.ToString + " - CERTINHO")
        Else
            ListBox1.Items.Add(resultados.ToString + " - Errou")
        End If
    End Sub

    Public Function base()
        Dim c As New Color
        Dim x, y As Double
        For Each i As Double In list
            x += i * i
            y += i
        Next
        Dim r As Double = x / y
        Label4.Text = r
        Me.Text = r
        If r > media Then
            c = Color.Green
            Me.Text += " SINAL VERDE ✓"
        Else
            c = Color.Red
            Me.Text += " SINAL VERMELHO X"
        End If
        If list.Count > 15 Then
            list.Remove(0)
        End If
        Return c
    End Function

    Private Sub TextBox2_KeyDown(sender As Object, e As KeyEventArgs) Handles TextBox2.KeyDown
        If e.KeyCode = Keys.Enter Then
            media = Integer.Parse(TextBox2.Text)
        End If
    End Sub

    Private Sub Form1_DoubleClick(sender As Object, e As EventArgs)
        Me.Close()
    End Sub

    Private Sub Form1_MouseDoubleClick(sender As Object, e As MouseEventArgs) Handles MyBase.MouseDoubleClick
        Application.Exit()
    End Sub

    Private Sub Form1_MouseMove(sender As Object, e As MouseEventArgs) Handles MyBase.MouseMove

        Do While e.Button = MouseButtons.Left
            Me.Top = Cursor.Position.Y
            Me.Left = Cursor.Position.X
            Exit Do
        Loop
    End Sub

    Private Sub Form1_MouseDown(sender As Object, e As MouseEventArgs) Handles MyBase.MouseDown
        If e.Button = MouseButtons.Right Then
            Me.WindowState = FormWindowState.Minimized
        End If
    End Sub
End Class
